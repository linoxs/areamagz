-- phpMyAdmin SQL Dump
-- version 2.11.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 05, 2009 at 06:43 PM
-- Server version: 5.1.30
-- PHP Version: 5.2.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Database: `areamagz`
--

-- --------------------------------------------------------

--
-- Table structure for table `access_controls`
--

CREATE TABLE IF NOT EXISTS `access_controls` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL,
  `module_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `role_id` (`role_id`),
  KEY `module_id` (`module_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=13 ;

--
-- Dumping data for table `access_controls`
--

INSERT INTO `access_controls` (`id`, `role_id`, `module_id`) VALUES
(1, 1, 1),
(2, 1, 2),
(3, 1, 3),
(4, 1, 4),
(5, 2, 1),
(6, 2, 2),
(7, 2, 3),
(8, 1, 5),
(9, 1, 6),
(10, 1, 7),
(11, 2, 6);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `label` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `description` text COLLATE latin1_general_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=10 ;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `label`, `description`) VALUES
(1, 'News Flash', NULL),
(2, 'Shopping', NULL),
(3, 'Speed Guide', NULL),
(4, 'Kids', NULL),
(5, 'Art & Culture', NULL),
(9, 'Entertainment', 'All about entertainment');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE IF NOT EXISTS `comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `time` datetime NOT NULL,
  `name` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `email` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `comment` text COLLATE latin1_general_ci NOT NULL,
  `entry_id` int(11) NOT NULL,
  `status` smallint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `entry_id` (`entry_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `comments`
--


-- --------------------------------------------------------

--
-- Table structure for table `entries`
--

CREATE TABLE IF NOT EXISTS `entries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime NOT NULL,
  `title` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `excerpt` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `body_text` text COLLATE latin1_general_ci,
  `category_id` int(11) NOT NULL DEFAULT '0',
  `author_id` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `thumb_image` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `url` varchar(255) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `category_id` (`category_id`),
  KEY `author_id` (`author_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `entries`
--

INSERT INTO `entries` (`id`, `created_at`, `title`, `excerpt`, `body_text`, `category_id`, `author_id`, `status`, `thumb_image`, `url`) VALUES
(1, '2009-06-05 01:28:21', '2 Metode untuk Jaring Pemilih di Luar Negeri  ', ' \\"Ini berlaku di wilayah-wilayah seperti perkebunan dan tempat yang terpencil di LN yang banyak pemilihnya. Jadi nanti koordinator akan mengantar dan menjemput kembali surat suara\\"', '<p><strong><img style=\\"border: 1px solid #ccc; float: left; margin-right:10px;\\" title=\\"Bendera Merah Putih\\" src=\\"http://192.168.11.42/area_cms/media/images/1244204566kpu-cover.jpg\\" alt=\\"Bendera Merah Putih\\" width=\\"200\\" height=\\"200\\" />Jakarta</strong> - Untuk menjaring lebih banyak pemilih di luar negeri, Komisi Pemilihan Umum (KPU) menyediakan 2 cara. Pemilih di luar negeri bisa datang ke tempat pemungutan suara (TPS) atau surat suara dikirimkan ke pemilih.<br /><br />\\"Pemilu di luar negeri terkait masalah logistik itu ada 3 hal yang menjadi pertimbangan. Yang pertama adalah lokasi yang jauh. Kedua banyaknya jumlah pemilih, dan yang ketiga metode yang digunakan,\\" ujar anggota KPU Andi Nurpati di kantornya, Jl Imam Bonjol, Menteng, Jakarta Pusat, Jumat (5/6/2009).<br /><br />Untuk metode Pilpres, imbuh Andi ada 2 metode. Pertama, pemilih datang langsung ke TPS yang ada di setiap perwakilan RI di luar negeri.<br /><br />\\"Dan ini memungkinkan ada lebih dari 1 TPS LN. Karena maksimal tiap TPS ada 800 pemilih,\\" imbuhnya.<br /><br />Metode yang kedua adalah metode pos, yang terdiri dari 2 cara. Yang pertama cara standar atau normal yaitu surat suara dikirim ke pemilih, kemudian setelah dicontreng dikirim kembali ke Panitia Pemilu Luar Negeri (PPLN).<br /><br />\\"Akan disiapkan 1 perangko yang sesuai dengan negara setempat dan amplop yang sudah dicetak setting alamat PPLN. Pengadaan ini sepenuhnya dilakukan PPLN setempat masing-masing negara,\\" jelas dia.<br /><br />Cara kedua adalah pos antaran. Nanti akan dibentuk tim khusus, Kelompok Penyelenggara Pemungutan Suara (KPPS) LN untuk mengurusi pos antaran. <br /><br />\\"Ini berlaku di wilayah-wilayah seperti perkebunan dan tempat yang terpencil di LN yang banyak pemilihnya. Jadi nanti koordinator akan mengantar dan menjemput kembali surat suara,\\" ujarnya.<br /><br />Metode pos dilakukan sebelum hari H dan maksimal 7 hari setelah hari H harus sudah diterima PPLN, dengan waktu toleransi 2 hari.<br /><br /> <strong> (	nwk	/	iy	) </strong></p>', 1, 1, 1, '1244204901kpu-cover.jpg', '2009/06/05/2-metode-untuk-jaring-pemilih');

-- --------------------------------------------------------

--
-- Table structure for table `modules`
--

CREATE TABLE IF NOT EXISTS `modules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `controller` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `description` text COLLATE latin1_general_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=9 ;

--
-- Dumping data for table `modules`
--

INSERT INTO `modules` (`id`, `name`, `controller`, `description`) VALUES
(1, 'Home', 'home', 'Dashboard of the system'),
(2, 'New Entry', 'new_entry', 'Write new entry'),
(3, 'Manage Entries', 'manage_entries', 'Manage existing entries'),
(4, 'Manage Comments', 'manage_comments', 'Manage incoming comments'),
(5, 'New User', 'new_user', 'Create new user'),
(6, 'Manage Assets', 'manage_assets', 'Manage images assets'),
(7, 'Manage Users', 'manage_users', 'Manage existing users');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE IF NOT EXISTS `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `description` text COLLATE latin1_general_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `description`) VALUES
(0, 'Demi God', 'I Own this system'),
(1, 'Administrator', 'Administrator of users, entries and comments'),
(2, 'Author', 'User of the system, write and manage entries');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `display_name` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `email` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `biography` text COLLATE latin1_general_ci,
  `website` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `userpic` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `password` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `role` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `role` (`role`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=9 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `display_name`, `email`, `biography`, `website`, `userpic`, `password`, `role`, `status`) VALUES
(1, 'linoxs', 'Desilino Muharyadi Putra', 'desilino.putra@mediasatu.com', '<p>was born in Depok - West Java. Experienced in Web Development for over than 3 years. If not doing his -just for fun- coding he usually found laying dead in the toilet until he found his sould back.</p>', 'http://twitter.com/linoxs', '1242653157gede1_thumb.jpg', 'e10adc3949ba59abbe56e057f20f883e', 0, 1),
(3, 'zoel', 'Zulkifli', 'zulkifli@mediasatu.com', '<p>Start his way of life as a Web activist as a humble student of our \\"Demi God\\" linoxs. Eventually working as Web Designer at MEDIASATU GROUP for almost 6 months. His destiny will soon reveal.</p>', 'http://gulali.890m.com', '1242655588vector_avatar.gif', 'e10adc3949ba59abbe56e057f20f883e', 1, 1),
(4, 'nicko', 'Nicko Krisna', '', '', 'http://www.clearafterhours.com/team/nicko_krisna/', '1242734858Lord-Raptor.jpg', 'e10adc3949ba59abbe56e057f20f883e', 2, 1),
(5, 'ferri', 'Ferri Ardiansyah', 'ferri.ardiansyah@mediasatu.com', '', '', NULL, 'e10adc3949ba59abbe56e057f20f883e', 2, 0),
(6, 'nevy', 'Nevy Elisa', NULL, NULL, NULL, NULL, 'e10adc3949ba59abbe56e057f20f883e', 2, 0),
(7, 'reza', 'Reza Puspo', NULL, NULL, NULL, NULL, 'e10adc3949ba59abbe56e057f20f883e', 1, 0),
(8, 'rara', 'Aksara Sophiaan', NULL, NULL, NULL, NULL, 'e10adc3949ba59abbe56e057f20f883e', 1, 0);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `access_controls`
--
ALTER TABLE `access_controls`
  ADD CONSTRAINT `access_controls_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`),
  ADD CONSTRAINT `access_controls_ibfk_2` FOREIGN KEY (`module_id`) REFERENCES `modules` (`id`);

--
-- Constraints for table `comments`
--
ALTER TABLE `comments`
  ADD CONSTRAINT `comments_ibfk_1` FOREIGN KEY (`entry_id`) REFERENCES `entries` (`id`);

--
-- Constraints for table `entries`
--
ALTER TABLE `entries`
  ADD CONSTRAINT `entries_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `entries_ibfk_2` FOREIGN KEY (`author_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`role`) REFERENCES `roles` (`id`) ON DELETE CASCADE;
